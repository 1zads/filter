# Shadowrocket·IP末段原样版·增强型 — subconverter 配置包

## 文件结构

```
SR_Enhanced_Config.zip
├── config/
│   └── SR_Enhanced.ini    ← 主配置文件（外部配置入口）
└── scripts/
    ├── filter.js           ← 节点过滤脚本（广告/过期/流量节点拦截）
    └── rename.js           ← 节点重命名脚本（国旗+城市+IP末段+协议+标签）
```

## 功能一览

| 功能 | 说明 | 开关位置 |
|------|------|----------|
| 🚫 广告过滤 | 丢弃含"广告/过期/流量/套餐"等关键词的节点 | `filter.js` + `exclude_remarks` |
| 🧹 推广词清洗 | 清除 TG@xxx、@用户名、节点/备用/线路等冗余词 | `rename.js` → `cleanName()` |
| 🚩 国家识别 | 60+ 国家/地区，匹配后加国旗 emoji | `rename.js` → `COUNTRY_MAP` |
| 🏙️ 城市代码 | 国家识别成功后自动追加三字城市码（LA/TYO/SIN…） | `rename.js` → `city` 字段 |
| 🔢 IP 末段 | IPv4 取第4段；域名节点用 host:port 哈希兜底 | `rename.js` → `getIpId()` |
| 📡 协议标识 | [SS]/[VMS]/[VLS]/[TRJ]/[HY2]/[TUIC] | `rename.js` → `getProto()` |
| 🏷️ 功能标签 | ChatGPT/Netflix/Disney/YouTube/TikTok 等 | `rename.js` → `TAG_MAP` |
| 📏 长度保护 | 超 55 字符自动截断 | `rename.js` → `MAX_LEN` |

## 使用方法

### 方式一：自托管（推荐）

1. 将 `config/` 和 `scripts/` 上传到你的 Web 服务器 / GitHub Pages / Vercel 等
2. 获取 `SR_Enhanced.ini` 的**直链 URL**（必须可公开访问）
3. 打开 `https://sub.cmliussss.com/`
4. 在「**自定义远程配置**」框中粘贴该 URL
5. 正常填写订阅链接 → 选择目标格式 → 生成

### 方式二：直接填入 subconverter 调用参数

```txt
http://你的后端地址:25500/sub?target=clash
  &url=你的订阅链接
  &config=https%3A%2F%2F你的域名%2Fconfig%2FSR_Enhanced.ini
  &token=你的token
```

> ⚠️ `filter_script` 和 `rename_node=!!script:` 出于安全考虑，必须通过 `token` 验证才会生效。

### 方式三：本地 subconverter

1. 下载并解压到 subconverter 根目录
2. 确保目录结构为：
   ```
   subconverter/
   ├── subconverter.exe / subconverter
   ├── config/SR_Enhanced.ini
   └── scripts/filter.js
   └── scripts/rename.js
   ```
3. 在浏览器/客户端中填入：
   ```
   http://127.0.0.1:25500/sub?target=clash&url=你的订阅&config=config/SR_Enhanced.ini
   ```

## 效果示例

| 原始节点名 | 转换后 |
|-----------|---------|
| 美国洛杉矶-ChatGPT专用节点-SS | 🇺🇸美国·LA-42 [SS]\|GPT |
| 新加坡V2Ray-Netflix | 🇸🇬新加坡·SIN-18 [VMS]\|NF |
| trojan-node-hk01 | 🇭🇰香港·HKG-99 [TRJ] |
| 日本东京Osaka-Game加速 | 🇯🇵日本·TYO-RY2 [VLS]\|GAME |
| 韩国首尔SEOUL-TikTok | 🇰🇷韩国·SEL-55 [VMS]\|TT |
| 英国London-UK-YouTube | 🇬🇧英国·LON-222 [VMS]\|YT |
| 广告节点-剩余流量1024G | ❌ 被过滤丢弃 |
| TG@spam 推广节点 套餐详情 | ❌ 被过滤丢弃 |

## 自定义开关

编辑 `scripts/rename.js` 顶部：

```js
var COUNTRY_ENABLED = true;   // 关 → false  // 关闭国家识别
var CITY_ENABLED    = true;   // 关 → false  // 关闭城市代码
var PROTO_ENABLED   = true;   // 关 → false  // 关闭协议标识
var IPID_ENABLED   = true;   // 关 → false  // 关闭IP末段
var TAG_ENABLED    = true;    // 关 → false  // 关闭功能标签
var CLEAN_ENABLED  = true;    // 关 → false  // 关闭推广词清洗
var LANG_CN        = true;    // 改 → false  // 国旗后显示英文(🇺🇸US)
var MAX_LEN        = 55;      // 改数字      // 节点名最大长度
```

## 与原 Shadowrocket 脚本的差异

| 项目 | 原版（SR 内嵌脚本） | 本配置（subconverter） |
|------|---------------------|----------------------|
| 运行环境 | Shadowrocket App 内部 | subconverter 后端 (QuickJS) |
| 节点对象 | `$server.title/uri/host/port` | `node.Remark/Hostname/Port/Type` |
| 地理库 | 无（纯正则） | 无（纯正则，保持一致） |
| filter | `return false` 丢弃 | `return false` 丢弃 |
| rename | 直接写 `$server.title` | `return` 新字符串 |
| emoji | 手动 unicode 转义 | 同左（`\uD83C\uDDFA` 等） |

## 注意事项

1. **路径问题**：`filter_script=path:scripts/filter.js` 中的路径是**相对于 subconverter 工作目录**的，确保文件放在正确位置
2. **token 安全**：远程调用 JS 脚本必须带 `&token=xxx`，否则脚本不会执行
3. **国旗显示**：部分老旧客户端可能不渲染 Unicode 国旗，属正常现象
4. **哈希 ID**：域名节点的 IP 末段用哈希生成，同一节点每次结果**稳定**（同 host:port 哈希值固定）
