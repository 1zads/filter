/*
 * Shadowrocket·IP末段原样版·增强型 — filter_script
 * 作用：过滤广告/过期/流量信息节点，命中即丢弃
 * subconverter 调用方式：filter_script=path:/path/to/filter.js
 */

function filter(node) {
    var title = node.Remark || "";
    if (!title) return false; // 无名称节点丢弃

    var bad = [
        "广告", "过期", "无效", "测试",
        "Expire", "剩余流量", "已用流量", "总流量",
        "Days", "Date", "Premium",
        "TEST", "USED", "TOTAL", "EXPIRE", "EMAIL",
        "流量：", "剩余：", "到期", "套餐"
    ];

    for (var i = 0; i < bad.length; i++) {
        if (title.indexOf(bad[i]) !== -1) return false;
    }

    return true; // 保留
}
