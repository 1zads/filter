/*
 * Shadowrocket·IP末段原样版·增强型 — rename_node script
 * 作用：节点重命名（国家国旗 + 城市 + IP末段 + 协议 + 功能标签）
 * subconverter 调用方式：rename_node=!!script:path:/path/to/rename.js
 *
 * node 对象可用字段：
 *   node.Remark   节点名称
 *   node.Hostname 主机名/IP
 *   node.Port     端口
 *   node.Type     协议类型
 *   node.EncryptMethod 加密方式
 *   geoip(host)  内置函数，返回 JSON {country_code, country, city}
 *
 * 设计原则：
 *   - 不用中文单字做 pattern（"加""法""日"等会跨词误匹配）
 *   - 只用完整词组 / 英文 / 数字编码 / 带 Unicode 边界的正则
 *   - 高频国家（HK/JP/SG/US/KR）排在前面
 */

/* ============ 功能开关 ============ */
var COUNTRY_ENABLED = true;
var CITY_ENABLED    = true;
var PROTO_ENABLED   = true;
var IPID_ENABLED   = true;
var TAG_ENABLED    = true;
var CLEAN_ENABLED  = true;
var LANG_CN        = true;
var MAX_LEN        = 55;

/* ============ 功能标签映射 ============ */
var TAG_MAP = [
    { patterns: ["ChatGPT","OpenAI","\\bAI\\b","\\bGPT\\b"],             tag: "|GPT"  },
    { patterns: ["Netflix","\\bNF\\b","奈飞"],                            tag: "|NF"   },
    { patterns: ["Disney","\\bDSN\\b","迪士尼"],                          tag: "|DSN"  },
    { patterns: ["YouTube","\\bYT\\b","油管"],                            tag: "|YT"   },
    { patterns: ["TikTok","\\bTT\\b","抖音"],                             tag: "|TT"   },
    { patterns: ["Spotify","\\bSP\\b","声破天"],                          tag: "|SP"   },
    { patterns: ["Game","\\bGAME\\b","游戏","Steam"],                     tag: "|GAME" },
    { patterns: ["Torrent","BT","PT","下载"],                              tag: "|BT"   }
];

/*
 * 国家/城市映射表
 *
 * 排序规则：
 *   1. 高频地区（HK/JP/SG/TW/KR/US）放最前
 *   2. 每个国家只用「完整词组」「英文」「数字编码」「带 (?<=...) 后顾」的 pattern
 *   3. 绝不使用裸中文单字（如 "加""法""日"），避免跨词误匹配
 *
 * NB = 非中文左边界，用于必须保留的单字缩写
 */
var NB = "(?:^|[^\\u4e00-\\u9fa5])";

var COUNTRY_MAP = [
    /* ===== 高频亚洲（最前） ===== */
    { cc: "HK", flag_cn: "\uD83C\uDDED\uD83C\uDDF0香港", flag_en: "\uD83C\uDDED\uD83C\uDDF0HK", city: "HKG",
      patterns: ["香港","Hong Kong","\\bHK\\b","HK\\d","HKT\\b","\\bHGC\\b","\\bWTT\\b","深港","沪港",
                 NB+"港"] },
    { cc: "JP", flag_cn: "\uD83C\uDDEF\uD83C\uDDF5日本", flag_en: "\uD83C\uDDEF\uD83C\uDDF5JP", city: "TYO",
      patterns: ["日本","Japan","Tokyo","Osaka","Nagoya","\\bJP\\b","JP\\d","东京","大阪","名古屋"] },
    { cc: "SG", flag_cn: "\uD83C\uDDF8\uD83C\uDDEC新加坡", flag_en: "\uD83C\uDDF8\uD83C\uDDECSG", city: "SIN",
      patterns: ["新加坡","Singapore","狮城","\\bSG\\b","SG\\d"] },
    { cc: "TW", flag_cn: "\uD83C\uDDF9\uD83C\uDDFC台湾", flag_en: "\uD83C\uDDF9\uD83C\uDDFCTW", city: "TPE",
      patterns: ["台湾","Taiwan","Taipei","Kaohsiung","\\bTW\\b","TW\\d","台北","高雄"] },
    { cc: "KR", flag_cn: "\uD83C\uDDF0\uD83C\uDDF7韩国", flag_en: "\uD83C\uDDF0\uD83C\uDDF7KR", city: "SEL",
      patterns: ["韩国","Korea","Seoul","Busan","\\bKR\\b","KR\\d","首尔","釜山"] },
    { cc: "TH", flag_cn: "\uD83C\uDDF9\uD83C\uDDED泰国", flag_en: "\uD83C\uDDF9\uD83C\uDDEDTH", city: "BKK",
      patterns: ["泰国","Thailand","Bangkok","Chiang Mai","\\bTH\\b","TH\\d","曼谷","清迈"] },
    { cc: "MY", flag_cn: "\uD83C\uDDF2\uD83C\uDDFE马来西亚", flag_en: "\uD83C\uDDF2\uD83C\uDDFEMY", city: "KUL",
      patterns: ["马来西亚","Malaysia","Kuala Lumpur","\\bMY\\b","MY\\d","吉隆坡"] },
    { cc: "VN", flag_cn: "\uD83C\uDDFB\uD83C\uDDF3越南", flag_en: "\uD83C\uDDFB\uD83C\uDDF3VN", city: "HAN",
      patterns: ["越南","Vietnam","Hanoi","Ho Chi Minh","\\bVN\\b","VN\\d","河内","胡志明"] },
    { cc: "PH", flag_cn: "\uD83C\uDDF5\uD83C\uDDED菲律宾", flag_en: "\uD83C\uDDF5\uD83C\uDDEDPH", city: "MNL",
      patterns: ["菲律宾","Philippines","Manila","\\bPH\\b","PH\\d","马尼拉"] },
    { cc: "IN", flag_cn: "\uD83C\uDDEE\uD83C\uDDF3印度", flag_en: "\uD83C\uDDEE\uD83C\uDDF3IN", city: "BOM",
      patterns: ["印度","India","Mumbai","Delhi","\\bIN\\b","IN\\d","孟买","德里"] },

    /* ===== 高频欧美 ===== */
    { cc: "US", flag_cn: "\uD83C\uDDFA\uD83C\uDDF8美国", flag_en: "\uD83C\uDDFA\uD83C\uDDF8US", city: "LA",
      patterns: ["美国","USA","States","American","\\bUS\\b","US\\d",
                 "Los Angeles","Seattle","New York","Chicago","Atlanta","Silicon",
                 "旧金山","圣何塞","西雅图","洛杉矶","纽约","芝加哥"] },
    { cc: "GB", flag_cn: "\uD83C\uDDEC\uD83C\uDDE7英国", flag_en: "\uD83C\uDDEC\uD83C\uDDE7GB", city: "LON",
      patterns: ["英国","UK","United Kingdom","London","Manchester","\\bGB\\b","GB\\d","伦敦","曼彻斯特","伯明翰"] },
    { cc: "DE", flag_cn: "\uD83C\uDDE9\uD83C\uDDEA德国", flag_en: "\uD83C\uDDE9\uD83C\uDDEADE", city: "FRA",
      patterns: ["德国","Germany","Frankfurt","Berlin","Munich","\\bDE\\b","DE\\d","柏林","慕尼黑","法兰克福"] },
    { cc: "FR", flag_cn: "\uD83C\uDDEB\uD83C\uDDF7法国", flag_en: "\uD83C\uDDEB\uD83C\uDDF7FR", city: "PAR",
      patterns: ["法国","France","Paris","Lyon","Marseille","\\bFR\\b","FR\\d","巴黎","里昂","马赛"] },
    { cc: "IT", flag_cn: "\uD83C\uDDEE\uD83C\uDDF9意大利", flag_en: "\uD83C\uDDEE\uD83C\uDDF9IT", city: "ROM",
      patterns: ["意大利","Italy","Rome","Milan","Naples","\\bIT\\b","IT\\d","罗马","米兰","那不勒斯"] },
    { cc: "ES", flag_cn: "\uD83C\uDDEA\uD83C\uDDF8西班牙", flag_en: "\uD83C\uDDEA\uD83C\uDDF8ES", city: "MAD",
      patterns: ["西班牙","Spain","Madrid","Barcelona","\\bES\\b","ES\\d","马德里","巴塞罗那"] },
    { cc: "NL", flag_cn: "\uD83C\uDDF3\uD83C\uDDF1荷兰", flag_en: "\uD83C\uDDF3\uD83C\uDDF1NL", city: "AMS",
      patterns: ["荷兰","Netherlands","Amsterdam","Rotterdam","\\bNL\\b","NL\\d","阿姆斯特丹","鹿特丹"] },
    { cc: "CH", flag_cn: "\uD83C\uDDE8\uD83C\uDDED瑞士", flag_en: "\uD83C\uDDE8\uD83C\uDDEDCH", city: "ZUR",
      patterns: ["瑞士","Switzerland","Zurich","Geneva","\\bCH\\b","CH\\d","苏黎世","日内瓦"] },

    /* ===== 加拿大（放后面，pattern 更严格） ===== */
    { cc: "CA", flag_cn: "\uD83C\uDDE8\uD83C\uDDE6加拿大", flag_en: "\uD83C\uDDE8\uD83C\uDDE6CA", city: "YYZ",
      patterns: ["加拿大","Canada","Toronto","Vancouver","Montreal","\\bCA\\b","CA\\d","多伦多","温哥华","蒙特利尔"] },

    /* ===== 其他欧洲 ===== */
    { cc: "SE", flag_cn: "\uD83C\uDDF8\uD83C\uDDEA瑞典", flag_en: "\uD83C\uDDF8\uD83C\uDDEASE", city: "STO",
      patterns: ["瑞典","Sweden","Stockholm","Gothenburg","\\bSE\\b","SE\\d","斯德哥尔摩"] },
    { cc: "NO", flag_cn: "\uD83C\uDDF3\uD83C\uDDF4挪威", flag_en: "\uD83C\uDDF3\uD83C\uDDF4NO", city: "OSL",
      patterns: ["挪威","Norway","Oslo","\\bNO\\b","NO\\d"] },
    { cc: "FI", flag_cn: "\uD83C\uDDFB\uD83C\uDDEE芬兰", flag_en: "\uD83C\uDDFB\uD83C\uDDEEFI", city: "HEL",
      patterns: ["芬兰","Finland","Helsinki","\\bFI\\b","FI\\d"] },
    { cc: "AT", flag_cn: "\uD83C\uDDE6\uD83C\uDDF9奥地利", flag_en: "\uD83C\uDDE6\uD83C\uDDF9AT", city: "VIE",
      patterns: ["奥地利","Austria","Vienna","\\bAT\\b","AT\\d","维也纳"] },
    { cc: "GR", flag_cn: "\uD83C\uDDEC\uD83C\uDDF7希腊", flag_en: "\uD83C\uDDEC\uD83C\uDDF7GR", city: "ATH",
      patterns: ["希腊","Greece","Athens","\\bGR\\b","GR\\d","雅典"] },
    { cc: "HU", flag_cn: "\uD83C\uDDED\uD83C\uDDFA匈牙利", flag_en: "\uD83C\uDDED\uD83C\uDDFAHU", city: "BUD",
      patterns: ["匈牙利","Hungary","Budapest","\\bHU\\b","HU\\d","布达佩斯"] },
    { cc: "CZ", flag_cn: "\uD83C\uDDE8\uD83C\uDDF8捷克", flag_en: "\uD83C\uDDE8\uD83C\uDDF8CZ", city: "PRG",
      patterns: ["捷克","Czech","Prague","\\bCZ\\b","CZ\\d","布拉格"] },
    { cc: "PL", flag_cn: "\uD83C\uDDF5\uD83C\uDDF1波兰", flag_en: "\uD83C\uDDF5\uD83C\uDDF1PL", city: "WAW",
      patterns: ["波兰","Poland","Warsaw","Krakow","\\bPL\\b","PL\\d","华沙","克拉科夫"] },
    { cc: "RO", flag_cn: "\uD83C\uDDF7\uD83C\uDDF4罗马尼亚", flag_en: "\uD83C\uDDF7\uD83C\uDDF4RO", city: "BUH",
      patterns: ["罗马尼亚","Romania","Bucharest","\\bRO\\b","RO\\d"] },
    { cc: "RS", flag_cn: "\uD83C\uDDF7\uD83C\uDDF8塞尔维亚", flag_en: "\uD83C\uDDF7\uD83C\uDDF8RS", city: "BEL",
      patterns: ["塞尔维亚","Serbia","Belgrade","\\bRS\\b","RS\\d"] },
    { cc: "LT", flag_cn: "\uD83C\uDDF1\uD83C\uDDF9立陶宛", flag_en: "\uD83C\uDDF1\uD83C\uDDF9LT", city: "VNO",
      patterns: ["立陶宛","Lithuania","Vilnius","\\bLT\\b","LT\\d"] },
    { cc: "DK", flag_cn: "\uD83C\uDDE9\uD83C\uDDF0丹麦", flag_en: "\uD83C\uDDE9\uD83C\uDDF0DK", city: "CPH",
      patterns: ["丹麦","Denmark","Copenhagen","\\bDK\\b","DK\\d","哥本哈根"] },
    { cc: "UA", flag_cn: "\uD83C\uDDFA\uD83C\uDDE6乌克兰", flag_en: "\uD83C\uDDFA\uD83C\uDDE6UA", city: "KIE",
      patterns: ["乌克兰","Ukraine","Kyiv","Lviv","\\bUA\\b","UA\\d","基辅"] },
    { cc: "IE", flag_cn: "\uD83C\uDDEE\uD83C\uDDEA爱尔兰", flag_en: "\uD83C\uDDEE\uD83C\uDDEAIE", city: "DUB",
      patterns: ["爱尔兰","Ireland","Dublin","\\bIE\\b","IE\\d","都柏林"] },
    { cc: "PT", flag_cn: "\uD83C\uDDF5\uD83C\uDDF9葡萄牙", flag_en: "\uD83C\uDDF5\uD83C\uDDF9PT", city: "LIS",
      patterns: ["葡萄牙","Portugal","Lisbon","\\bPT\\b","PT\\d","里斯本"] },
    { cc: "BE", flag_cn: "\uD83C\uDDE7\uD83C\uDDEA比利时", flag_en: "\uD83C\uDDE7\uD83C\uDDEABE", city: "BRU",
      patterns: ["比利时","Belgium","Brussels","\\bBE\\b","BE\\d"] },
    { cc: "CY", flag_cn: "\uD83C\uDDF0\uD83C\uDDFE塞浦路斯", flag_en: "\uD83C\uDDF0\uD83C\uDDFECY", city: "NIC",
      patterns: ["塞浦路斯","Cyprus","Nicosia","\\bCY\\b","CY\\d"] },

    /* ===== 中东 / 西亚 ===== */
    { cc: "TR", flag_cn: "\uD83C\uDDF9\uD83C\uDDF7土耳其", flag_en: "\uD83C\uDDF9\uD83C\uDDF7TR", city: "IST",
      patterns: ["土耳其","Turkey","Istanbul","Ankara","\\bTR\\b","TR\\d","伊斯坦布尔"] },
    { cc: "IL", flag_cn: "\uD83C\uDDEE\uD83C\uDDF1以色列", flag_en: "\uD83C\uDDEE\uD83C\uDDF1IL", city: "TLV",
      patterns: ["以色列","Israel","Jerusalem","Tel Aviv","\\bIL\\b","IL\\d"] },
    { cc: "SA", flag_cn: "\uD83C\uDDF8\uD83C\uDDE6沙特", flag_en: "\uD83C\uDDF8\uD83C\uDDE6SA", city: "RUH",
      patterns: ["沙特","Saudi","Riyadh","Jeddah","\\bSA\\b","SA\\d","利雅得"] },
    { cc: "AE", flag_cn: "\uD83C\uDDE6\uD83C\uDDEA阿联酋", flag_en: "\uD83C\uDDE6\uD83C\uDDEAAE", city: "DXB",
      patterns: ["阿联酋","UAE","Dubai","Abu Dhabi","\\bAE\\b","AE\\d","迪拜"] },
    { cc: "PK", flag_cn: "\uD83C\uDDF5\uD83C\uDDF0巴基斯坦", flag_en: "\uD83C\uDDF5\uD83C\uDDF0PK", city: "ISB",
      patterns: ["巴基斯坦","Pakistan","Islamabad","\\bPK\\b","PK\\d"] },
    { cc: "IR", flag_cn: "\uD83C\uDDEE\uD83C\uDDF7伊朗", flag_en: "\uD83C\uDDEE\uD83C\uDDF7IR", city: "THR",
      patterns: ["伊朗","Iran","Tehran","\\bIR\\b","IR\\d","德黑兰"] },
    { cc: "IQ", flag_cn: "\uD83C\uDDEE\uD83C\uDDF6伊拉克", flag_en: "\uD83C\uDDEE\uD83C\uDDF6IQ", city: "BGW",
      patterns: ["伊拉克","Iraq","Baghdad","\\bIQ\\b","IQ\\d","巴格达"] },
    { cc: "NP", flag_cn: "\uD83C\uDDF3\uD83C\uDDF5尼泊尔", flag_en: "\uD83C\uDDF3\uD83C\uDDF5NP", city: "KTM",
      patterns: ["尼泊尔","Nepal","Kathmandu","\\bNP\\b","NP\\d","加德满都"] },

    /* ===== 北美洲 ===== */
    { cc: "MX", flag_cn: "\uD83C\uDDF2\uD83C\uDDFD墨西哥", flag_en: "\uD83C\uDDF2\uD83C\uDDFDMX", city: "MEX",
      patterns: ["墨西哥","Mexico","Mexico City","\\bMX\\b","MX\\d"] },
    { cc: "GT", flag_cn: "\uD83C\uDDEC\uD83C\uDDF9危地马拉", flag_en: "\uD83C\uDDEC\uD83C\uDDF9GT", city: "GUA",
      patterns: ["危地马拉","Guatemala","\\bGT\\b","GT\\d"] },
    { cc: "CR", flag_cn: "\uD83C\uDDE8\uD83C\uDDF7哥斯达黎加", flag_en: "\uD83C\uDDE8\uD83C\uDDF7CR", city: "SJO",
      patterns: ["哥斯达黎加","Costa Rica","\\bCR\\b","CR\\d"] },

    /* ===== 南美洲 ===== */
    { cc: "BR", flag_cn: "\uD83C\uDDE7\uD83C\uDDF7巴西", flag_en: "\uD83C\uDDE7\uD83C\uDDF7BR", city: "SAO",
      patterns: ["巴西","Brazil","São Paulo","Sao Paulo","Rio","\\bBR\\b","BR\\d","圣保罗","里约"] },
    { cc: "AR", flag_cn: "\uD83C\uDDE6\uD83C\uDDF7阿根廷", flag_en: "\uD83C\uDDE6\uD83C\uDDF7AR", city: "BUE",
      patterns: ["阿根廷","Argentina","Buenos Aires","\\bAR\\b","AR\\d"] },
    { cc: "CL", flag_cn: "\uD83C\uDDE8\uD83C\uDDF1智利", flag_en: "\uD83C\uDDE8\uD83C\uDDF1CL", city: "SCL",
      patterns: ["智利","Chile","Santiago","\\bCL\\b","CL\\d"] },
    { cc: "PE", flag_cn: "\uD83C\uDDF5\uD83C\uDDEA秘鲁", flag_en: "\uD83C\uDDF5\uD83C\uDDEAPE", city: "LIM",
      patterns: ["秘鲁","Peru","Lima","\\bPE\\b","PE\\d"] },
    { cc: "CO", flag_cn: "\uD83C\uDDE8\uD83C\uDDF4哥伦比亚", flag_en: "\uD83C\uDDE8\uD83C\uDDF4CO", city: "BOG",
      patterns: ["哥伦比亚","Colombia","Bogotá","Bogota","\\bCO\\b","CO\\d"] },
    { cc: "EC", flag_cn: "\uD83C\uDDEA\uD83C\uDDE8厄瓜多尔", flag_en: "\uD83C\uDDEA\uD83C\uDDE8EC", city: "UIO",
      patterns: ["厄瓜多尔","Ecuador","Quito","\\bEC\\b","EC\\d"] },
    { cc: "BO", flag_cn: "\uD83C\uDDE7\uD83C\uDDF4玻利维亚", flag_en: "\uD83C\uDDE7\uD83C\uDDF4BO", city: "LPZ",
      patterns: ["玻利维亚","Bolivia","Sucre","La Paz","\\bBO\\b","BO\\d"] },

    /* ===== 大洋洲 ===== */
    { cc: "AU", flag_cn: "\uD83C\uDDE6\uD83C\uDDFA澳洲", flag_en: "\uD83C\uDDE6\uD83C\uDDFAAU", city: "SYD",
      patterns: ["澳洲","澳大利亚","Australia","Sydney","Melbourne","Brisbane","\\bAU\\b","AU\\d","悉尼","墨尔本","布里斯班"] },
    { cc: "NZ", flag_cn: "\uD83C\uDDF3\uD83C\uDDFF新西兰", flag_en: "\uD83C\uDDF3\uD83C\uDDFFNZ", city: "AKL",
      patterns: ["新西兰","New Zealand","Auckland","\\bNZ\\b","NZ\\d","奥克兰"] },

    /* ===== 非洲 ===== */
    { cc: "ZA", flag_cn: "\uD83C\uDDFF\uD83C\uDDE6南非", flag_en: "\uD83C\uDDFF\uD83C\uDDE6ZA", city: "JNB",
      patterns: ["南非","South Africa","Johannesburg","Cape Town","\\bZA\\b","ZA\\d"] },
    { cc: "EG", flag_cn: "\uD83C\uDDEA\uD83C\uDDEC埃及", flag_en: "\uD83C\uDDEA\uD83C\uDDECEG", city: "CAI",
      patterns: ["埃及","Egypt","Cairo","\\bEG\\b","EG\\d","开罗"] },
    { cc: "DZ", flag_cn: "\uD83C\uDDE9\uD83C\uDDFF阿尔及利亚", flag_en: "\uD83C\uDDE9\uD83C\uDDFFDZ", city: "ALG",
      patterns: ["阿尔及利亚","Algeria","Algiers","\\bDZ\\b","DZ\\d"] },
    { cc: "MA", flag_cn: "\uD83C\uDDF2\uD83C\uDDE6摩洛哥", flag_en: "\uD83C\uDDF2\uD83C\uDDE6MA", city: "RAB",
      patterns: ["摩洛哥","Morocco","Rabat","\\bMA\\b","MA\\d"] },
    { cc: "NG", flag_cn: "\uD83C\uDDF3\uD83C\uDDEC尼日利亚", flag_en: "\uD83C\uDDF3\uD83C\uDDECNG", city: "LOS",
      patterns: ["尼日利亚","Nigeria","Lagos","\\bNG\\b","NG\\d"] }
];

/* ============ 辅助函数 ============ */
function cleanName(name) {
    if (!CLEAN_ENABLED) return name;
    var s = name
        .replace(/TG@\S+/gi, "")
        .replace(/t\.me\/\S+/gi, "")
        .replace(/@[A-Za-z0-9_]{3,}/g, "");
    var dirty = ["节点","备用","线路","官方","订阅",
                 "套餐","会员","客服","官网","群","频道","邀请","返利",
                 "推广","获取","更新","Premium","Days","Date"];
    for (var d = 0; d < dirty.length; d++) {
        s = s.split(dirty[d]).join(" ");
    }
    return s.replace(/[\|\-\—\–\·\s]+/g, " ").trim();
}

function matchCountry(src) {
    for (var i = 0; i < COUNTRY_MAP.length; i++) {
        var c = COUNTRY_MAP[i];
        for (var j = 0; j < c.patterns.length; j++) {
            var re = new RegExp(c.patterns[j], "i");
            if (re.test(src)) return c;
        }
    }
    return null;
}

function getIpId(host, port) {
    if (!IPID_ENABLED) return "";
    if (host && /^\d+\.\d+\.\d+\.\d+$/.test(host)) {
        return host.split(".")[3];
    }
    // 域名节点回退：host:port 哈希
    var s = host + ":" + (port || "");
    var h = 0;
    for (var i = 0; i < s.length; i++) {
        h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    }
    return Math.abs(h).toString(36).substring(0, 3).toUpperCase();
}

function getProto(type) {
    if (!PROTO_ENABLED) return "";
    if (!type) return "";
    var t = type.toLowerCase();
    if (t === "ss") return "[SS]";
    if (t === "vmess") return "[VMS]";
    if (t === "vless") return "[VLS]";
    if (t === "trojan") return "[TRJ]";
    if (t.indexOf("hysteria") === 0) return "[HY2]";
    if (t === "tuic") return "[TUIC]";
    return "";
}

function getTags(src) {
    if (!TAG_ENABLED) return "";
    var tags = "";
    for (var i = 0; i < TAG_MAP.length; i++) {
        var item = TAG_MAP[i];
        for (var j = 0; j < item.patterns.length; j++) {
            var re = new RegExp(item.patterns[j], "i");
            if (re.test(src)) {
                if (tags.indexOf(item.tag) === -1) tags += item.tag;
                break;
            }
        }
    }
    return tags;
}

/* ============ 主入口 ============ */
function rename(node) {
    var title  = node.Remark || "";
    var host   = node.Hostname || "";
    var port   = node.Port || "";
    var type   = node.Type || "";

    if (!title) return "";

    var src   = title + " " + host;
    var clean = cleanName(title);

    /* 国家识别 */
    var flag = "";
    var cc   = "";
    var city = "";
    if (COUNTRY_ENABLED) {
        var matched = matchCountry(clean);
        if (matched) {
            flag = LANG_CN ? matched.flag_cn : matched.flag_en;
            cc   = matched.cc;
            city = matched.city;
        }
    }

    /* IP 末段 */
    var ipId = getIpId(host, port);

    /* 协议 */
    var proto = getProto(type);

    /* 功能标签 */
    var tags = getTags(src);

    /* 组装 */
    var out = "";
    if (flag) {
        out += flag;
        if (city) out += "·" + city;
        if (ipId) out += "-" + ipId;
        if (proto) out += " " + proto;
        if (tags)  out += tags;
    } else {
        out += clean;
        if (ipId) out += "-" + ipId;
        if (proto) out += " " + proto;
        if (tags)  out += tags;
    }

    /* 长度保护 */
    if (out.length > MAX_LEN) out = out.substring(0, MAX_LEN);

    return out;
}
